KTech

This mod adds a few weapons and items from Star Trek and Star Wars, as well as a couple of new and original SciFi weapons like a Space missile and a super powerful Rail gun. These parts are super OP, and are meant for pure unadulterated fun and destruction!

Star Trek:

Photon Torpedo - Functions like the HE-KV-1 and has a 100km range

Federation Phaser Turret

NX Class Phaser Cannon

Klingon Phaser Cannon

---------------------------------------------------------------------------------------------------------------------------------------
Star Wars:

R2D2 - Advanced probe core with MechJeb capability, and full BDAc weapon manager!

Turbo Laser Cannon

Turbo Laser Turret

X10 Laser

X10b Laser

X10 Double Laser

----------------------------------------------------------------------------------------------------------------------------------------

Original:

Rail Gun Turret

S1 Space Missile - Functions like the HE-KV-1 and has a 100km range

Space Radar - Needed for super long range targeting in space, 

----------------------------------------------------------------------------------------------------------------------------------------

Dependencies: 

BDArmory Continued v1.2 https://forum.kerbalspaceprogram.com/index.php?/topic/155014-14x-bdarmory-continued-v12-4232018-vessel-mover-camera-tools-bdmk22-destruction-effects-burn-together/&

Optional Dependencies:

For S1 Space missile texture switching, you will require SM_Industries https://github.com/SpannerMonkey/SMIndustries/releases

For R2D2 MechJeb functionality, you will need MechJeb https://ksp.sarbian.com/jenkins/job/MechJeb2-Dev/


Model creators: 

SpannerMonkey(smce)

BahamutoD - Original creator of BDArmory.

Devo - R2D2 Model.